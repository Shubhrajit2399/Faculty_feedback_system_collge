<?php
include("../database_con.php");
session_start();
//header("location:set-feedback.php");
$usr=$_POST["username"];
$pswd=$_POST["password"];
$rpswd=$_POST["c_password"];
$btch=$_SESSION["ss_btch"];
$sem=$_SESSION["ss_sem"];
$warn1="";
$msg="";
if(!empty($sem) && !empty($btch) && !empty($usr) && !empty($pswd) && !empty($rpswd)){
	if($pswd ==  $rpswd){
		$store="update slogin set username='$usr', password='$pswd' where sem='$sem'and batch='$btch'";
		$i=mysqli_query($con,$store);
    
   		echo "<script>alert('Successfully Done!');window.location='set-feedback.php';</script>";
	}
	else{
			$warn1="<h3 style='color:Red;'>Enter right password!!</h3>";
		header("location:editdata.php?warn1=".$warn1);
	}
}
else{
	$msg="<h3 style='color:Red;'>All fields are required to entered!!</h3>";
		header("location:editdata.php?msg=".$msg);
}
?>