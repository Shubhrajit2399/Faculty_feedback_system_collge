<?php
include("../database_con.php");
session_start();
if (! empty ($_SESSION["sem"])){
	$sem=$_SESSION["sem"];
	$btch=$_SESSION["batch"];
	$dt=$_SESSION["dt"];
	$s="select sub1,teacher1,sub2,sub3,sub4,sub5,sub6 from  details where batch='$btch' and sem='$sem'";
	$result=mysqli_query($con,$s);
}
else{
	header("location:../index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Feedback | 1st Subject </title>
	<link rel="shortcut icon" type="image/x-icon" href="../images/Hit logo png.png"/>
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/form.css">
</head>
<body>

	<div class="wrapper">
		<!--=================[ Header ]=================-->
		<div class="header">
			<div class="header-top">
				<div class="header-top-left">
					<marquee>
						<p> Welcome to online feedback system . . . !</p>
					</marquee>
				</div>
				<div class="header-top-right">
					<div class="header-menu">
						<ul>
							<li>
								<a href=""> Home </a>
								
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="header-body">
				<div class="logo">
					<div class="logo_font">
						<img src="../images/Hit logo png.png" alt="HIT-logo" >
					</div>
				</div>
				<div class="title">
					<p>
						<font id="title_name"><u>Haldia Institute of Technology</u></font><br>
						<font id="title_add1">Icare Complex, HIT Campus, P.O.- HIT,</font><br>
						<font id="title_add2">Haldia, Purba Medinipur, Pin- 721657</font>
					</p>
				</div>
			</div>
		</div>
		<!--=================[ Container ]=================-->
		<div class="container">
			<div class="container-menu">
				<div class="container-menu-left">
					<p>CSE's Feedback</p>
				</div>
				<div class="container-menu-right">
					<div id="navbar">
					  <a href="../adminlogout.php">Log Out</a>
					</div>
				</div>
			</div>
			<div class="container-body">
				<div class="container-body-left">
					<h1 id="side-menu-head-text1">: Semester :</h1>
					<h1 id="side-menu-head-text2">Select Subject</h1>
					<div class="side-menu">
					<?php
                     while($row=mysqli_fetch_assoc($result)){
                    ?>
						<ul>
							<li><a href="../feedback.php">Feedback home</a></li>
							
							<li class="active"><?php echo $row["sub1"]; ?></li>
							<li><a href="pages/sub2.php"><?php echo $row["sub2"]; ?></a></li>
							<li><a href="pages/sub3.php"><?php echo $row["sub3"]; ?></a></li>
							<li><a href="pages/sub4.php"><?php echo $row["sub4"]; ?></a></li>
							<li><a href="pages/sub5.php"><?php echo $row["sub5"]; ?></a></li>
							<li><a href="pages/sub6.php"><?php echo $row["sub6"]; ?></a></li>
						</ul>
					</div>
				</div>
				<div class="container-body-right">
					<div class="container-body-right-top">
						<h1> Give your Feedback for :  <h1>
					</div>
					<div class="container-body-right-body">
					<h1 id="text">Feedback Form :</h1>
						 <center>	
							
								<table>										
									<tr><p>&nbsp;</p></tr>
									<tr><th colspan="2">Please Fill Your Center</th></th>
										<tr>
											<td id="question"> Subject :  </td>
											<td id="ans"> <?php echo $row['sub1'] ;?></td>
										</tr>
				
										<tr>
											<td id="question">Teacher's Name : </td>
											<td id="ans"><?php echo $row['teacher1'] ;?></td>
										</tr>
										<?php
										$_SESSION["ss_sub1"]=$row["sub1"];
										$_SESSION["ss_teacher1"]=$row["teacher1"];
										}
											?>
											<form action="sub1process.php" method="POST" name="feedbackform">
										<tr><td colspan = "2" id="question">1. Knowledge base of the teacher (as perceived by you)</td></tr>
										<tr><td colspan = "2" id="ans">
												<input type="radio" name="KB" value="100" checked>Very Good
												<input type="radio" name="KB" value="80">Good
												<input type="radio" name="KB" value="60">Fair
												<input type="radio" name="KB" value="40">Satifactory
												<input type="radio" name="KB" value="20">Unsatifactory  
											</td>
											
										</tr>
			
										<tr><td colspan = "2" id="question">2. Communication Skills (in terms of articulation and comprehensibility)</td></tr>
										<tr><td colspan = "2" id="ans"> 
											<input type="radio" name="Com" value="100" checked>	Very Good
											<input type="radio" name="Com" value="80">Good
											<input type="radio" name="Com" value="60">Fair
											<input type="radio" name="Com" value="40">Satifactory
											<input type="radio" name="Com" value="20">Unsatifactory  
											</td>
										</tr>
			
										<tr><td colspan = "2" id="question">3. Sincerity / Commitment of the teacher</td></tr>
										<tr><td colspan = "2" id="ans">
											<input type="radio" name="SC" value="100"checked>Very Good
											<input type="radio" name="SC" value="80">Good
											<input type="radio" name="SC" value="60">Fair
											<input type="radio" name="SC" value="40">Satifactory
											<input type="radio" name="SC" value="20">Unsatifactory  
											</td>
										</tr>
			
										<tr><td colspan = "2" id="question">4. Interest generated by the teacher</td></th>
										<tr><td colspan = "2" id="ans">
											<input type="radio" name="IG" value="100"checked>Very Good
											<input type="radio" name="IG" value="80">Good
											<input type="radio" name="IG" value="60">Fair
											<input type="radio" name="IG" value="40">Satifactory
											<input type="radio" name="IG" value="20">Unsatifactory 
											</td>
										</tr>
			
										<tr><td colspan = "2" id="question">5. Whether the teacher regularly engages classes as per the timetable?</td></tr>
										<tr><td colspan = "2" id="ans">
											<input type="radio" name="EC" value="100"checked>Very Good
											<input type="radio" name="EC" value="80">Good
											<input type="radio" name="EC" value="60">Fair
											<input type="radio" name="EC" value="40">Satifactory
											<input type="radio" name="EC" value="20">Unsatifactory
											</td>
										</tr>
										
										<tr><td colspan = "2" id="question">6. Whether the teacher takes full class as per allotted time (50 min.)</td></tr>
										<tr><td colspan = "2" id="ans">
											<input type="radio" name=" AT" value="100"checked>Very Good
											<input type="radio" name=" AT" value="80">Good
											<input type="radio" name=" AT" value="60">Fair
											<input type="radio" name=" AT" value="40">Satifactory
											<input type="radio" name=" AT" value="20">Unsatifactory  
											</td>
										</tr>
										
										<tr><td colspan = "2" id="question">7. Does the teacher completes the subject as per the syllabus</td></tr>
										<tr><td colspan = "2" id="ans">
											<input type="radio" name="PS" value="100"checked>Very Good
											<input type="radio" name="PS" value="80">Good
											<input type="radio" name="PS" value="60">Fair
											<input type="radio" name="PS" value="40">Satifactory
											<input type="radio" name="PS" value="20">Unsatifactory  
											</td>
										</tr>
										
										<tr><td colspan = "2" id="question">8. Rate the internal assessment evaluation by the teacher</td></tr>
										<tr><td colspan = "2" id="ans">
											<input type="radio" name="IA" value="100"checked>Very Good
											<input type="radio" name="IA" value="80">Good
											<input type="radio" name="IA" value="60">Fair
											<input type="radio" name="IA" value="40">Satifactory
											<input type="radio" name="IA" value="20">Unsatifactory  
											</td>
										</tr>
														
										<tr>
										  <td id="question"> Any Remarks </td>
										  <td id="ans"> <textarea name="R" rows="5" cols="40"></textarea>  </td>
										</tr>
										<tr><td></td></tr><tr><td></td></tr>
										<tr>
											<td align="center"><input type="submit" name="submit" class="btn" value="Submit" /></td>
											</form>
											<td align="center"><input type="reset" class="btn" value="Reset"/></td>
										</tr>
										<tr><td></td></tr>
										<tr><td></td></tr>
										<tr><td></td></tr>
								</table>
							
						</center>
					</div>
				</div>
			</div>
		</div>
		<!--=================[ Footer ]=================-->
		<div class="footer">
			<p align="Center"> Haldia Institute of Technology | Design by <a href="#">Dolon kr. Nayak(B.Tech CSE 2018) </a> </p>
			
		</div>
	</div>	
	
<script>
/*=====[ for Container-Menu ]=====*/

/*************************************/
</script>
	
	
</body>	
</html>