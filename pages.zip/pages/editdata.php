<?php
include("../database_con.php");
session_start();
$usr=$_SESSION["ss_usr"];
$pswd=$_SESSION["ss_pswd"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin panel</title>
	<link rel="shortcut icon" type="image/x-icon" href="../images/Hit logo png.png"/>
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/admin.css">
	<link rel="stylesheet" href="../css/form.css">
</head>
<body>

	<div class="wrapper">
		<!--=================[ Header ]=================-->
		<div class="header">
			<div class="header-top">
				<div class="header-top-left">
					<marquee>
						<p> Welcome to online feedback system . . . !</p>
					</marquee>
				</div>
				<div class="header-top-right">
					<div class="header-menu">
						<ul>
							<li>
								<a href=""> Home </a>
								
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="header-body">
				<div class="logo">
					<div class="logo_font">
						<img src="../images/Hit logo png.png" alt="HIT-logo" >
					</div>
				</div>
				<div class="title">
					<p>
						<font id="title_name"><u>Haldia Institute of Technology</u></font><br>
						<font id="title_add1">Icare Complex, HIT Campus, P.O.- HIT,</font><br>
						<font id="title_add2">Haldia, Purba Medinipur, Pin- 721657</font>
					</p>
				</div>
			</div>
		</div>
		<!--=================[ Container ]=================-->
		<div class="container">
			<div class="container-menu">
				<div class="container-menu-left">
					<p>CSE's Feedback</p>
				</div>
				<div class="container-menu-right">
					<div id="navbar">
					  <a href="">Admin </a>
					</div>
				</div>
			</div>
			<div class="container-body">
				<div class="container-body-left">
					<h1 id="side-menu-head-text1">: Admin :</h1>
					<h1 id="side-menu-head-text2">Select Option</h1>
					<div class="side-menu">
						<ul>
							<li><a href="../admin-panel.php">Dashboard</a></li>
							<li  class="active"><a href="">Setup feedback</a></li>
							<li><a href="setup-details.php">Setup Details </a></li>
							<li><a href="">View Result</a></li>
								<!--<ul class="dropdown-content">
									<li><a href="">Semester 1</a></li>
									<li><a href="">Semester 2</a></li>
									<li><a href="">Semester 3</a></li>
									<li><a href="">Semester 4</a></li>
									<li><a href="">Semester 5</a></li>
									<li><a href="">Semester 6</a></li>
									<li><a href="">Semester 7</a></li>
									<li><a href="">Semester 8</a></li>
								</ul>
								-->
							<li><a href=".php">empty</a></li>
							
						</ul>
					</div>
				</div>
				<div class="container-body-right">
					<div class="container-body-right-top">
						<h1>Setup feedback Control. <h1>
					</div>
					<div class="container-body-right-body">
						<h1 id="text">Setup here todays feedback control :</h1>
						 <center>	
							
							<form action="editdata_process.php" method="POST" name="editdata">
								<table>										
									<tr><p>&nbsp;</p></tr>
									<tr><td></td></tr>
									<tr><th colspan="2">Please Fill Your Center</th></th>
									<tr><td></td></tr>
									
									<tr>
										<td>User name for semester : </td>
										<td><input type="text"  name="username" class="box" value="<?php echo $usr ?>" required /></td>
									</tr>
		
									<tr>
										<td>Password : </td>	
										<td><input type="password" name="password" required class="box" value="<?php echo $pswd ?>" required /></td>
									</tr>
									
									<tr>
										<td>Confrom Password : </td>	
										<td><input type="password" name="c_password" required class="box" placeholder="enter your password again"/></td>
									</tr>		
									<tr>
									
									<tr><td></td></tr><tr><td></td></tr>
									<tr>
										<td align="center"><input type="submit" name="Save" class="btn" value="Save" /></td>
										</form>
									</tr>
									<tr><td></td></tr>
									<tr><td><?php if(isset($_REQUEST['warn1'])) echo $_REQUEST['warn1']; ?>
 		    								<?php if(isset($_REQUEST['msg'])) echo $_REQUEST['msg']; ?></td></tr>
									<tr><td></td></tr>
								</table>
							
						</center>
						
						
					</div>
				</div>
			</div>
		</div>
		<!--=================[ Footer ]=================-->
		<div class="footer">
			<p align="Center"> Haldia Institute of Technology | Design by <a href="#">Dolon kr. Nayak(B.Tech CSE 2018) </a> </p>
			
		</div>
	</div>		
</body>	
</html>