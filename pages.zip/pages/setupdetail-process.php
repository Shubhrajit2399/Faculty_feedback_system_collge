<?php
include("../database_con.php");
session_start();
$sem=$_POST["Sem"];
$btch=$_POST["batch"];
$date=$_POST["date"];
$sub1=$_POST["sub1"];
$teacher1=$_POST["teacher1"];
$sub2=$_POST["sub2"];
$teacher2=$_POST["teacher2"];
$sub3=$_POST["sub3"];
$teacher3=$_POST["teacher3"];
$sub4=$_POST["sub4"];
$teacher4=$_POST["teacher4"];
$sub5=$_POST["sub5"];
$teacher5=$_POST["teacher5"];
$sub6=$_POST["sub6"];
$teacher6=$_POST["teacher6"];/*
$store="insert into details(sem,batch,dt,sub1,teacher1,sub2,teacher2,sub3,teacher3,sub4,teacher4,sub5,teacher5,sub6,teacher6) values('$sem','$btch','$date','$sub1','$teacher1','$sub2','$teacher2','$sub3','$teacher3','$sub4','$teacher4','$sub5','$teacher5','$sub6','$teacher6')";
		$i=mysqli_query($con,$store);
    
   		 echo "<script>alert('Successfully Done!');window.location='setup-details.php';</script>";*/
  $s="insert into details(sem,batch,dt,sub1,teacher1,sub2,teacher2,sub3,teacher3,sub4,teacher4,sub5,teacher5,sub6,teacher6) values('$sem','$btch','$date','$sub1','$teacher1','$sub2','$teacher2','$sub3','$teacher3','$sub4','$teacher4','$sub5','$teacher5','$sub6','$teacher6')";
  $i=mysqli_query($con,$s);
   echo "<script>alert('Successfully Done!');window.location='../admin-panel.php';</script>";
?>