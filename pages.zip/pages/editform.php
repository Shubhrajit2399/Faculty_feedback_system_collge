<?php
include("../database_con.php");
session_start();


	//if ($con) echo "dbconnected";
	//else
	//	die("Error " . mysqli_error($con));

/*if (isset($_POST['Save'])) {
			
    $sem = $_POST['sem'];
	$batch = $_POST['batch'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	echo $sem;
	$sql = "INSERT INTO slogin (sem,batch,username,password) 
			VALUES ('$sem','$batch','$username,'$password');";
			
	$slogin = mysqli_query($con,$sql);
	if ($slogin)
		echo "success";
	else
		echo "Mysql_error()";


}*/
	?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin panel</title>
	<link rel="shortcut icon" type="image/x-icon" href="../images/Hit logo png.png"/>
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/admin.css">
	<link rel="stylesheet" href="../css/form.css">
</head>
<body>

	<div class="wrapper">
		<!--=================[ Header ]=================-->
		<div class="header">
			<div class="header-top">
				<div class="header-top-left">
					<marquee>
						<p> Welcome to online feedback system . . . !</p>
					</marquee>
				</div>
				<div class="header-top-right">
					<div class="header-menu">
						<ul>
							<li>
								<a href=""> Home </a>
								
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="header-body">
				<div class="logo">
					<div class="logo_font">
						<img src="../images/Hit logo png.png" alt="HIT-logo" >
					</div>
				</div>
				<div class="title">
					<p>
						<font id="title_name"><u>Haldia Institute of Technology</u></font><br>
						<font id="title_add1">Icare Complex, HIT Campus, P.O.- HIT,</font><br>
						<font id="title_add2">Haldia, Purba Medinipur, Pin- 721657</font>
					</p>
				</div>
			</div>
		</div>
		<!--=================[ Container ]=================-->
		<div class="container">
			<div class="container-menu">
				<div class="container-menu-left">
					<p>CSE's Feedback</p>
				</div>
				<div class="container-menu-right">
					<div id="navbar">
					  <a href="">Admin </a>
					</div>
				</div>
			</div>
			<div class="container-body">
				<div class="container-body-left">
					<h1 id="side-menu-head-text1">: Admin :</h1>
					<h1 id="side-menu-head-text2">Select Option</h1>
					<div class="side-menu">
						<ul>
							<li><a href="../admin-panel.php">Dashboard</a></li>
							<li  class="active"><a href="">Setup feedback</a></li>
							<li><a href="setup-details.php">Setup Details </a></li>
							<li><a href="">View Result</a></li>
								<!--<ul class="dropdown-content">
									<li><a href="">Semester 1</a></li>
									<li><a href="">Semester 2</a></li>
									<li><a href="">Semester 3</a></li>
									<li><a href="">Semester 4</a></li>
									<li><a href="">Semester 5</a></li>
									<li><a href="">Semester 6</a></li>
									<li><a href="">Semester 7</a></li>
									<li><a href="">Semester 8</a></li>
								</ul>
								-->
							<li><a href=".php">empty</a></li>
							
						</ul>
					</div>
				</div>
				<div class="container-body-right">
					<div class="container-body-right-top">
						<h1>Setup feedback Control. <h1>
					</div>
					<div class="container-body-right-body">
						<h1 id="text">Setup here todays feedback control :</h1>
						 <center>	
							
							<form action="editlogin_process.php" method="POST" name="set-feedback">
								<table>										
									<tr><p>&nbsp;</p></tr>
									<tr><td></td></tr>
									<tr><th colspan="2">Please Fill Your Center</th></th>
									<tr><td></td></tr>
									<tr>
										<td> Semester :  </td>
										<td><select name="Sem">
												<option value="Semester 1">Semester 1</option>
												<option value="Semester 2">Semester 2</option>
												<option value="Semester 3">Semester 3</option>
												<option value="Semester 4">Semester 4</option>
												<option value="Semester 5">Semester 5</option>
												<option value="Semester 6">Semester 6</option>
												<option value="Semester 7">Semester 7</option>
												<option value="Semester 8">Semester 8</option>
											</select>
										</td>
									</tr>
									
									<tr>
										<td> Batch :  </td>
										<td><select name="batch">
												<option>Batch 1</option>
												<option>Batch 2</option>
											</select>
										</td>
									</tr>
			
									
										<td align="center"><input type="submit" name="Submit" class="btn" value="Go" /></td>
										</form>
										
									<tr><td></td></tr>
									<tr><td></td></tr>
									<tr><td></td></tr>
								</table>
							
						</center>
						
						
					</div>
				</div>
			</div>
		</div>
		<!--=================[ Footer ]=================-->
		<div class="footer">
			<p align="Center"> Haldia Institute of Technology | Design by <a href="#">Dolon kr. Nayak(B.Tech CSE 2018) </a> </p>
			
		</div>
	</div>		
</body>	
</html>