<!DOCTYPE html>
<html>
<head>
	<title>Admin panel</title>
	<link rel="shortcut icon" type="image/x-icon" href="../images/Hit logo png.png"/>
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/admin.css">
	<link rel="stylesheet" href="../css/form.css">
</head>
<body>

	<div class="wrapper">
		<!--=================[ Header ]=================-->
		<div class="header">
			<div class="header-top">
				<div class="header-top-left">
					<marquee>
						<p> Welcome to online feedback system . . . !</p>
					</marquee>
				</div>
				<div class="header-top-right">
					<div class="header-menu">
						<ul>
							<li>
								<!--<a href="../index"> Home </a>-->
								
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="header-body">
				<div class="logo">
					<div class="logo_font">
						<img src="../images/Hit logo png.png" alt="HIT-logo" >
					</div>
				</div>
				<div class="title">
					<p>
						<font id="title_name"><u>Haldia Institute of Technology</u></font><br>
						<font id="title_add1">Icare Complex, HIT Campus, P.O.- HIT,</font><br>
						<font id="title_add2">Haldia, Purba Medinipur, Pin- 721657</font>
					</p>
				</div>
			</div>
		</div>
		<!--=================[ Container ]=================-->
		<div class="container">
			<div class="container-menu">
				<div class="container-menu-left">
					<p>CSE's Feedback</p>
				</div>
				<div class="container-menu-right">
					<div id="navbar">
					  <a href="">Admin </a>
					</div>
				</div>
			</div>
			<div class="container-body">
				<div class="container-body-left">
					<h1 id="side-menu-head-text1">: Admin :</h1>
					<h1 id="side-menu-head-text2">Select Option</h1>
					<div class="side-menu">
						<ul>
							<li><a href="../admin-panel.php">Dashboard</a></li>
							<li><a href="../pages/set-feedback.php">Setup feedback</a></li>
							<li   class="active"><a href="">Setup Details </a></li>
							<li><a href="view.php">View Result</a></li>
								<!--<ul class="dropdown-content">
									<li><a href="">Semester 1</a></li>
									<li><a href="">Semester 2</a></li>
									<li><a href="">Semester 3</a></li>
									<li><a href="">Semester 4</a></li>
									<li><a href="">Semester 5</a></li>
									<li><a href="">Semester 6</a></li>
									<li><a href="">Semester 7</a></li>
									<li><a href="">Semester 8</a></li>
								</ul>
								-->
							<li><a href=".php">empty</a></li>
							
						</ul>
					</div>
				</div>
				<div class="container-body-right">
					<div class="container-body-right-top">
						<h1>Setup feedback Control. <h1>
					</div>
					<div class="container-body-right-body">
						<h1 id="text">Enter Subject & Teacher's Name :</h1>
						 <center>	
							<form action="setupdetail-process.php" method="POST" name="setup-details">
								<table>										
									<tr><p>&nbsp;</p></tr>
									<tr><td></td></tr>
									<tr><td></td></tr>
									<tr><th colspan="4">Please Fill Your Center</th></th>
									<tr><td></td></tr>
									<tr>
										<td> Semester :  </td>
										<td><select name="Sem">
												<option value="Semester 1">Semester 1</option>
												<option value="Semester 2">Semester 2</option>
												<option value="Semester 3">Semester 3</option>
												<option value="Semester 4">Semester 4</option>
												<option value="Semester 5">Semester 5</option>
												<option value="Semester 6">Semester 6</option>
												<option value="Semester 7">Semester 7</option>
												<option value="Semester 8">Semester 8</option>
											</select>
										</td>
										
									</tr>
										<td>Batch : </td>
										<td><select name="batch">
												<option value="Batch 1">Batch 1</option>
												<option value="Batch 2">Batch 2</option>
											</select>
										</td>
										<td> Date:</td>
										<td><input type="date" class="box" name="date" /><td>
									<tr>
										<td colspan="4">Enter Subject & Teacher name</td> 
									</tr>
		
									<tr>
										<td>Subject: 1 </td>
										<td><input type="text"  name="sub1" class="box" placeholder="eg. Subject" required /></td>
										<td>Teacher Name : </td>
										<td><input type="text"  name="teacher1" class="box" placeholder="eg. Teacher's Name" required /></td>
									</tr>
									<tr>
										<td>Subject: 2 </td>
										<td><input type="text"  name="sub2" class="box" placeholder="eg. Subject" ></td>
										<td>Teacher Name : </td>
										<td><input type="text"  name="teacher2" class="box" placeholder="eg. Teacher's Name" ></td>
									</tr>
									<tr>
										<td>Subject: 3 </td>
										<td><input type="text"  name="sub3" class="box" placeholder="eg. Subject"></td>
										<td>Teacher Name : </td>
										<td><input type="text"  name="teacher3" class="box" placeholder="eg. Teacher's Name" ></td>
									</tr>
									<tr>
										<td>Subject: 4 </td>
										<td><input type="text"  name="sub4" class="box" placeholder="eg. Subject"></td>
										<td>Teacher Name : </td>
										<td><input type="text"  name="teacher4" class="box" placeholder="eg. Teacher's Name"></td>
									</tr>
									<tr>
										<td>Subject: 5 </td>
										<td><input type="text"  name="sub5" class="box" placeholder="eg. Subject"></td>
										<td>Teacher Name : </td>
										<td><input type="text"  name="teacher5" class="box" placeholder="eg. Teacher's Name"></td>
									</tr>
									<tr>
										<td>Subject: 6 </td>
										<td><input type="text"  name="sub6" class="box" placeholder="eg. Subject"  /></td>
										<td>Teacher Name : </td>
										<td><input type="text"  name="teacher6" class="box" placeholder="eg. Teacher's Name"  /></td>
									</tr>
									
									<tr><td></td></tr><tr><td></td></tr>
									<tr>
										<td colspan="2" align="center"><input type="submit" name="Submit" class="btn" value="Submit" /></td>
										</form>
										<td colspan="2" align="center"><a href="setupdetails_editlogin.php"><input type="submit" name="Submit" class="btn" value="Reset"/></a></td>
									</tr>
									<tr><td></td></tr>
									<tr><td></td></tr>
									<tr><td></td></tr>
								</table>
							
						</center>
						
						
					</div>
				</div>
			</div>
		</div>
		<!--=================[ Footer ]=================-->
		<div class="footer">
			<p align="Center"> Haldia Institute of Technology | Design by <a href="#">Dolon kr. Nayak(B.Tech CSE 2018) </a> </p>
			
		</div>
	</div>		
</body>	
</html>