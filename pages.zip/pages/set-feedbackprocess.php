<?php
include("../database_con.php");
session_start();
//header("location:set-feedback.php");
$sem=$_POST["Sem"];
$btch=$_POST["batch"];
$usr=$_POST["username"];
$pswd=$_POST["password"];
$rpswd=$_POST["c_password"];
$warn1="";
$msg="";
if(!empty($sem) && !empty($btch) && !empty($usr) && !empty($pswd) && !empty($rpswd)){
	if($pswd ==  $rpswd){
		$store="insert into slogin(sem,batch,username,password) values('$sem', '$btch', '$usr', '$pswd')";
		$i=mysqli_query($con,$store);
    
   		 echo "<script>alert('Successfully Done!');window.location='set-feedback.php';</script>";
	}
	else{
			$warn1="<h3 style='color:Red;'>Enter right password!!</h3>";
		header("location:set-feedback.php?warn1=".$warn1);
	}
}
else{
	$msg="<h3 style='color:Red;'>All fields are required to entered!!</h3>";
		header("location:set-feedback.php?msg=".$msg);
}
?>