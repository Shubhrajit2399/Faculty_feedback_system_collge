<?php
include("../database_con.php");

$sem=$_POST["Sem"];
$batch=$_POST["batch"];
$sub=$_POST["sub"];
$dt=$_POST["dt"];
$a="select sem,batch,dt,sub,teacher,KB,com,sc,ig,ec,at,ps,ia,R,avgg from feedback where BINARY sem=BINARY '$sem' and BINARY batch=BINARY '$batch' and BINARY sub=BINARY '$sub' and BINARY sub=BINARY '$sub' and BINARY dt=BINARY '$dt'";
$d=mysqli_query($con,$a);
if($row=mysqli_fetch_assoc($d)){
	session_start();
	$_SESSION["ss_sem"]=$row["sem"];
	$_SESSION["ss_batch"]=$row["batch"];
	$_SESSION["ss_dt"]=$row["dt"];
	$_SESSION["ss_sub"]=$row["sub"];
	$_SESSION["ss_teacher"]=$row["teacher"];
	$_SESSION["ss_KB"]=$row["KB"];
	$_SESSION["ss_com"]=$row["com"];
	$_SESSION["ss_sc"]=$row["sc"];
	$_SESSION["ss_ig"]=$row["ig"];
	$_SESSION["ss_ec"]=$row["ec"];
	$_SESSION["ss_at"]=$row["at"];
	$_SESSION["ss_ps"]=$row["ps"];
	$_SESSION["ss_ia"]=$row["ia"];
	$_SESSION["ss_R"]=$row["R"];
	$_SESSION["ss_avgg"]=$row["avgg"];
	
	echo "<script>window.location='view.php';</script>";
 }
 
else{
	echo "<script>alert('Invalid Input. Please try again.'),window.location='view.php';</script>";
}
?>