<?php
include("../database_con.php");
session_start();
$sem=$_SESSION["sem"];
$btch=$_SESSION["batch"];
$dt=$_SESSION["dt"];
$t=$_SESSION["ss_teacher1"];
$sub=$_SESSION["ss_sub1"];
$kb=$_POST["KB"];
$comm=$_POST["Com"];
$scc=$_POST["SC"];
$igg=$_POST["IG"];
$ecc=$_POST["EC"];
$att=$_POST["AT"];
$pss=$_POST["PS"];
$iaa=$_POST["IA"];
$remm=$_POST["R"];
$avgg=($kb+$comm+$scc+$igg+$ecc+$att+$pss+$iaa)/8;
$s="insert into feedback (sem,batch,dt,sub,teacher,KB,com,sc,ig,ec,at,ps,ia,R,avgg) values ('$sem','$btch','$dt','$sub','$t','$kb','$comm','$scc','$igg','$ecc','$att','$pss','$iaa','$remm','$avgg')";
$i=mysqli_query($con,$s);

echo "<script>alert('Done Successfully');window.location='../feedback.php';</script>";

?>
