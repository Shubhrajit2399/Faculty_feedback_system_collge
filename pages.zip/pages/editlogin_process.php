<?php
include("../database_con.php");
$sem=$_POST["Sem"];
$btch=$_POST["batch"];
$s="select username,password,sem,batch from slogin where sem='$sem' and batch='$btch'";
$i=mysqli_query($con,$s);
if($row=mysqli_fetch_assoc($i)){
session_start();
	$_SESSION["ss_usr"]=$row["username"];
	$_SESSION["ss_pswd"]=$row["password"];
	$_SESSION["ss_sem"]=$row["sem"];
	$_SESSION["ss_btch"]=$row["batch"];
	echo "<script>window.location='editdata.php'</script>";
  }
?>