<?php
include("../database_con.php");
session_start();
$sem=$_SESSION["ss_sem"];
$btch=$_SESSION["ss_batch"];
$dt=$_SESSION["ss_dt"];
$sub=$_SESSION["ss_sub"];
$teacher=$_SESSION["ss_teacher"];
/*$kb=$_SESSION["ss_KB"];
$com=$_SESSION["ss_com"];
$sc=$_SESSION["ss_sc"];
$ig=$_SESSION["ss_ig"];
$ec=$_SESSION["ss_ec"];
$at=$_SESSION["ss_at"];
$ps=$_SESSION["ss_ps"];
$ia=$_SESSION["ss_ia"];
$R=$_SESSION["ss_R"];
$avg=$_SESSION["ss_avgg"];*/
$s="select KB,com,sc,ig,ec,at,ps,ia,R,avgg from feedback where sem='$sem' and batch='$btch' and dt='$dt' and sub='$sub'";
$i=mysqli_query($con,$s);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin panel</title>
	<link rel="shortcut icon" type="image/x-icon" href="../images/Hit logo png.png"/>
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/admin.css">
	<link rel="stylesheet" href="../css/form.css">
</head>
<body>

	<div class="wrapper">
		<!--=================[ Header ]=================-->
		<div class="header">
			<div class="header-top">
				<div class="header-top-left">
					<marquee>
						<p> Welcome to online feedback system . . . !</p>
					</marquee>
				</div>
				<div class="header-top-right">
					<div class="header-menu">
						<ul>
							<li>
								<a href=""> Home </a>
								
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="header-body">
				<div class="logo">
					<div class="logo_font">
						<img src="../images/Hit logo png.png" alt="HIT-logo" >
					</div>
				</div>
				<div class="title">
					<p>
						<font id="title_name"><u>Haldia Institute of Technology</u></font><br>
						<font id="title_add1">Icare Complex, HIT Campus, P.O.- HIT,</font><br>
						<font id="title_add2">Haldia, Purba Medinipur, Pin- 721657</font>
					</p>
				</div>
			</div>
		</div>
		<!--=================[ Container ]=================-->
		<div class="container">
			<div class="container-menu">
				<div class="container-menu-left">
					<p>CSE's Feedback</p>
				</div>
				<div class="container-menu-right">
					<div id="navbar">
					  <a href="">Admin </a>
					</div>
				</div>
			</div>
			<div class="container-body">
				<div class="container-body-left">
					<h1 id="side-menu-head-text1">: Admin :</h1>
					<h1 id="side-menu-head-text2">Select Option</h1>
					<div class="side-menu">
						<ul>
							<li><a href="../admin-panel.php">Dashboard</a></li>
							<li><a href="set-feedback.php">Setup feedback</a></li>
							<li><a href="setup-details.php">Setup Details </a></li>
							<li class="active" ><a href="">View Result</a></li>
								
							<li><a href="#.php">empty</a></li>
							
						</ul>
					</div>
				</div>
				<div class="container-body-right">
					<div class="container-body-right-top">
						<h1>View Result. <h1>
					</div>
					<div class="container-body-right-body">
						<h1 id="text">Feedback Result :</h1><br><br><br><br>
						 <center>	
							<form action="#.php" method="POST" name="viewfeedback">
								<table border="1">										
									<tr><th colspan="11">Check The Feedback Result</th></th>
									
									<tr>
										<td rowspan="2"> <img src="../images/Hit logo png.png" id="view-logo" alt="HIT-logo" > </td>
										<td rowspan="2" colspan="5"> 
											<p>
												<font id="view-title"><b><u>Haldia Institute of Technology</u></b></font><br>
												<font id="view-add">Icare Complex, HIT Campus, P.O.- HIT,<br>
												Haldia, Purba Medinipur, Pin- 721657</font>
											</p>
										</td>
										<td> Deparment: </td> 
										<td> CSE </td>
										
										<td> Semester: </td> 
										<td><?php echo $sem; ?></td>
									</tr>
									<tr>
										<td> Batch: </td> 
										<td><?php echo $btch; ?></td>
										
										<td> Date: </td> 
										<td><?php echo $dt; ?></td>
									</tr>
									<tr>
										<td colspan="2">Subject :</td>
										<td colspan="2"><?php echo $sub; ?></td>
										<td colspan="2">Teacher Name: </td>
										<td colspan="2"><?php echo $teacher; ?></td>
											
										<td></td>
									</tr>
									
									<tr>
										
										<td>Knowledge</td>
										<td>Communication Skills</td>
										<td>Sincerity</td>
										<td>Interest</td>
										<td>regularly engages classes</td>
										<td> allotted time</td>
										<td>completes syllabus</td>
										<td>internal assessment</td>
										<td>Any Remarks</td>
										<td>Overall</td>
									</tr>

									<tr><?php
										$sum =0;
										$n =0;
										while($row=mysqli_fetch_assoc($i)){
										?>	
										<td><?php echo $row["KB"]; ?> </td>
										<td><?php echo $row["com"]; ?></td>
										<td><?php echo $row["sc"]; ?></td>
										<td><?php echo $row["ig"]; ?></td>
										<td><?php echo $row["ec"]; ?></td>
										<td><?php echo $row["at"]; ?></td>
										<td><?php echo $row["ps"]; ?></td>
										<td><?php echo $row["ia"]; ?></td>
										<td><?php echo $row["R"]; ?></td>
										<td><?php echo $row["avgg"]; ?></td>
										<?php
										$sum += $row["avgg"];
										$n++;

										?>
									</tr>
									
									<?php
								}
								$final = $sum/$n;
								echo "overall percentage:".$final;
								
																	?>
								</table>
							</form>
						</center>
						
						
					</div>
				</div>
			</div>
		</div>
		<!--=================[ Footer ]=================-->
		<div class="footer">
			<p align="Center"> Haldia Institute of Technology | Design by <a href="#">Dolon kr. Nayak(B.Tech CSE 2018) </a> </p>
			
		</div>
	</div>		
</body>	
</html>