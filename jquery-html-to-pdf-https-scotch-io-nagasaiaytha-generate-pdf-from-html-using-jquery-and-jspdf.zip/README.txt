A Pen created at CodePen.io. You can find this one at https://codepen.io/nagasai/pen/JKKNMK.

 https://scotch.io/@nagasaiaytha/generate-pdf-from-html-using-jquery-and-jspdf